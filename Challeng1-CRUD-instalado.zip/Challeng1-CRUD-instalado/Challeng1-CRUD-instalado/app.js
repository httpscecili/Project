document.getElementById('myForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const pic = document.getElementById("imgInput").files[0];
    const name = document.getElementById("name").value;
    const age = document.getElementById("age").value;
    const city = document.getElementById("city").value;
    const email = document.getElementById("email").value;
    const phone = document.getElementById("phone").value;
    const post = document.getElementById("post").value;
    const sDate = document.getElementById("sDate").value;

    const newUser = {
        id: Date.now(),
        pic: pic ? URL.createObjectURL(pic) : "./image/Profile Icon.webp",
        name,
        age,
        city,
        email,
        phone,
        post,
        sDate
    };

    let getData = localStorage.getItem('userProfile') ? JSON.parse(localStorage.getItem('userProfile')) : [];
    getData.push(newUser);
    localStorage.setItem('userProfile', JSON.stringify(getData));

    showInfo();

    const modal = bootstrap.Modal.getInstance(document.getElementById('userForm'));
    modal.hide();

    document.getElementById("myForm").reset();
    document.querySelector(".img").src = "./image/Profile Icon.webp";
});

function showInfo() {
    let getData = localStorage.getItem('userProfile') ? JSON.parse(localStorage.getItem('userProfile')) : [];
    document.querySelectorAll('.employeeDetails').forEach(info => info.remove());

    getData.forEach((element, index) => {
        let createElement = `<tr class="employeeDetails">
            <td>${index + 1}</td>
            <td><img src="${element.pic}" alt="" width="50" height="50"></td>
            <td>${element.name}</td>
            <td>${element.age}</td>
            <td>${element.city}</td>
            <td>${element.email}</td>
            <td>${element.phone}</td>
            <td>${element.post}</td>
            <td>${element.sDate}</td>
            <td>
                <button class="btn btn-success" onclick="readInfo('${element.pic}', '${element.name}', '${element.age}', '${element.city}', '${element.email}', '${element.phone}', '${element.post}', '${element.sDate}')" data-bs-toggle="modal" data-bs-target="#readData"><i class="bi bi-eye"></i></button>
                <button class="btn btn-primary" onclick="editInfo(${index}, '${element.pic}', '${element.name}', '${element.age}', '${element.city}', '${element.email}', '${element.phone}', '${element.post}', '${element.sDate}')" data-bs-toggle="modal" data-bs-target="#userForm"><i class="bi bi-pencil-square"></i></button>
                <button class="btn btn-danger" onclick="deleteInfo(${index})"><i class="bi bi-trash"></i></button>
            </td>
        </tr>`;
        document.getElementById('data').insertAdjacentHTML('beforeend', createElement);
    });
}
showInfo();

function readInfo(pic, name, age, city, email, phone, post, sDate) {
    document.querySelector('.showImg').src = pic;
    document.querySelector('#showName').value = name;
    document.querySelector("#showAge").value = age;
    document.querySelector("#showCity").value = city;
    document.querySelector("#showEmail").value = email;
    document.querySelector("#showPhone").value = phone;
    document.querySelector("#showPost").value = post;
    document.querySelector("#showsDate").value = sDate;
}

function editInfo(index, pic, name, Age, City, Email, Phone, Post, Sdate) {
    isEdit = true;
    editId = index;
    document.querySelector('.img').src = pic;
    document.getElementById('name').value = name;
    document.getElementById('age').value = Age;
    document.getElementById('city').value = City;
    document.getElementById('email').value = Email;
    document.getElementById('phone').value = Phone;
    document.getElementById('post').value = Post;
    document.getElementById('sDate').value = Sdate;

    document.querySelector('.submit').innerText = "Update";
    document.querySelector('.modal-title').innerText = "Update The Form";
}

function deleteInfo(index) {
    if (confirm("Are you sure you want to delete?")) {
        let getData = localStorage.getItem('userProfile') ? JSON.parse(localStorage.getItem('userProfile')) : [];
        getData.splice(index, 1);
        localStorage.setItem("userProfile", JSON.stringify(getData));
        showInfo();
    }
}

document.querySelector('.newUser').addEventListener('click', () => {
    document.querySelector('.submit').innerText = "Submit";
    document.querySelector('.modal-title').innerText = "Fill The Form";
    document.getElementById("myForm").reset();
    document.querySelector(".img").src = "./image/Profile Icon.webp";
});
